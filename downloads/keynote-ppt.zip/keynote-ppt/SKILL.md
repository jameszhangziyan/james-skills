---
name: keynote-ppt
description: "Create high-impact, design-forward keynote presentations in one of three premium styles: SpaceX (industrial roadshow), NVIDIA (keynote/cinematic), or McKinsey (consulting/analytical). Sources cinematic imagery from Unsplash/Pexels and routes final PPTX generation through the local ppt-master skill for quality and stability."
metadata:
  version: "2.1.0"
  styles: ["spacex", "nvidia", "mckinsey"]
  requires:
    - ppt-master skill (PPTX engine)
    - python-pptx (for QA proxy thumbnails only)
    - Pillow (for proxy thumbnails in inspect_deck.py)
    - requests (for scripts/fetch_image.py)
  optional:
    - PyMuPDF (for PDF-based thumbnails in inspect_deck.py)
    - LibreOffice (soffice) for high-fidelity PPTX -> PDF rendering
    - UNSPLASH_ACCESS_KEY / PEXELS_API_KEY
---

# Keynote PPT Skill

## Role

Act as a senior presentation designer and story strategist. Build persuasive, visually premium keynotes in one of three selectable styles. Every deck must feel intentional, not templated: one hero visual per slide, one decisive claim, and one proof point.

Treat brand names as creative shorthand only. Never reproduce official logos, screenshots presented as original work, or language implying endorsement.

## When to use

- Fundraising / investor pitches
- Product launches and keynotes
- Strategic consulting readouts
- Business cases and leadership alignment
- Any request that says "SpaceX style", "NVIDIA style", "McKinsey style", or "premium/cinematic presentation"

## Input Requirements (must confirm before building)

- [ ] **Style**: `spacex` | `nvidia` | `mckinsey`
- [ ] **Decision goal**: What must the audience do after this deck? (fund / approve / partner / align)
- [ ] **One-sentence takeaway**: If they remember only one sentence, what is it?
- [ ] **Hero number**: The single most important number + unit + time + source
- [ ] **Audience**: Investor, board, customer, internal leadership, public keynote?
- [ ] **Length**: 8–12 slides for investor/keynote; 15–30 for consulting deep-dive
- [ ] **Outline or raw material**: Bullet outline, memo, data, or existing deck
- [ ] **Image sourcing**: Confirm whether to auto-search Unsplash/Pexels or use provided URLs

## Workflow

1. **Clarify inputs** using the requirements above. If the outline is thin, propose a concise story before producing slides.
2. **Choose style** and load the matching `references/design-system-<style>.md`.
3. **Build a story card** using `references/story-card-template.md`. Define: decision, takeaway, tension, turning point, evidence, ask.
4. **Map slide types** using `references/slide-types.md`. Assign a type to every slide (cover, stakes, proof, chart, product, ask, etc.).
5. **Source images** with `scripts/fetch_image.py` for every slide that needs a visual anchor. One slide gets one strong image. Prefer real-world photography for SpaceX/NVIDIA; prefer clean charts/diagrams for McKinsey.
6. **Generate PPTX** through `$ppt-master` (Generate PPTX route). Provide the story card, slide type map, design system, and image manifest so the deck uses native master/layouts, vector graphics, and ppt-master's quality gates. Run the full `$ppt-master` pipeline: initialize project, prepare images, author SVG pages, run `svg_quality_checker.py`, then export with `svg_to_pptx.py`. Do not use `scripts/build_deck.py` as a shortcut.
7. **Inspect and fix** with `scripts/inspect_deck.py`. Check: text overflow, contrast, image bleeding, thumbnail clarity, 3-second readability.
8. **Deliver** the final PPTX, a summary of design choices, presenter notes, and image credits.

## Style Selection Guide

| Style | Best for | Mood | Background | Hero Visual | Data Density |
|-------|----------|------|------------|-------------|--------------|
| `spacex` | Fundraising, investor decks, deep-tech | Industrial, mission-led, precise | Black | Full-bleed industrial/space/hardware photography | High (metric grids) |
| `nvidia` | Keynotes, product launches, AI infrastructure | Cinematic, futuristic, confident | Black | Product/hardware renders, architecture diagrams, data-center photography | Medium (specs + diagrams) |
| `mckinsey` | Strategy consulting, board readouts, due diligence | Analytical, rigorous, clear | White | Charts, frameworks, driver trees, roadmaps | Very high (charts + frameworks) |

## Image Sourcing Rules

- Every slide must have a visual anchor. The anchor can be:
  - **Background image**: full-bleed with gradient overlay (SpaceX/NVIDIA)
  - **Product/schematic image**: isolated on black or white background
  - **Diagram**: generated as a PNG/SVG or built with PPTX shapes
  - **Chart**: built from data, not a decorative image
- For SpaceX/NVIDIA, search Unsplash/Pexels for: hardware, data center, factory, space, rocket, chip, server rack, industrial materials, night operations, atmospheric horizons.
- For McKinsey, images are secondary. Use icons, simple shapes, and clean charts. Only search for a relevant concept photo if it strengthens the argument.
- Run `scripts/fetch_image.py` with style-aware keywords. Example: `--style spacex --query "rocket launch night industrial"`.
- Preserve image source, creator, URL, and license in the presenter notes or a credits appendix.
- Do not use watermarked, low-resolution, or off-topic images. If free sources fail, tell the user before using paid stock.

## Story Architecture

Use this chain so the deck is easy to present, not merely easy to read:

| Beat | Question | Slide job | Evidence |
|------|----------|-----------|----------|
| Stakes | Why care now? | Costly status quo or ambition | One scale metric |
| Friction | What is broken? | Constraint, bottleneck, asymmetry | One fact, quote, or benchmark |
| Insight | What changed? | Non-obvious causal insight | Before/after or mechanism |
| Turning Point | Why does this work? | Decisive system, decision, asset | Operating metric or unit-economic driver |
| Proof | Why believe it? | Verified performance | 1–3 traceable numbers |
| Consequence | What becomes possible? | Upside, moat, strategic implication | Scenario, milestone, market outcome |
| Ask | What next? | One precise decision request | Amount, owner, timeline, next gate |

For McKinsey, compress the same logic into the **Pyramid Principle**: conclusion first, then mutually exclusive supporting arguments, then evidence.

## Writing Direction

- **Titles must be conclusions**, not section labels. "A $4B INFLECTION POINT", not "Market Opportunity".
- Use one hero number per slide. At most two supporting numbers unless the slide is explicitly analytical.
- Avoid unsupported adjectives ("massive", "leading", "transformative"). Replace with comparison, change rate, market share, rank, cost delta, or time-to-value.
- For McKinsey: action titles must be a full sentence stating the slide's takeaway.
- For SpaceX/NVIDIA: titles can be shorter and punchier, but still must carry a point.

## Visual QA Checklist

Before delivery, run `scripts/inspect_deck.py` and fix any issue:

- [ ] No text is clipped or overlapping.
- [ ] Background images have enough contrast for text (apply overlay if needed).
- [ ] Every slide's point is clear within 3 seconds of thumbnail view.
- [ ] Color palette is consistent with the chosen style.
- [ ] Fonts are embedded or safe fallbacks are used.
- [ ] Every image has source attribution in notes.
- [ ] Charts are readable and axes are labeled.
- [ ] Final slide has a single, clear ask.

## Guardrails

- Say "SpaceX-inspired", "NVIDIA-inspired", or "McKinsey-inspired"; never label output as official work.
- Do not use official logos, screenshots presented as original, or branded assets.
- Respect licensing, source attribution, factual accuracy, accessibility, and readability before visual drama.
- Never fabricate data. If a number is unknown, flag it and ask the user.

## Fallbacks

- If `python-pptx` is unavailable, install it: `pip install python-pptx`.
- If image API keys are unavailable, `fetch_image.py` will print candidate URLs and ask the user to confirm or provide their own.
- If the user does not provide a hero number or clear ask, stop and ask before building slides.
- If `$ppt-master` is not available, install or activate it first. `scripts/build_deck.py` is retained only as a reference implementation and must not be used for delivered decks.
