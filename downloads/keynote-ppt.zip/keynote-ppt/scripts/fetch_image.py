#!/usr/bin/env python3
"""
Fetch premium images for keynote-ppt decks.

Supports Unsplash and Pexels APIs. Falls back to search URLs if no API keys.
Usage:
    python3 fetch_image.py --style spacex --query "rocket launch night" --outdir ./images
    python3 fetch_image.py --style nvidia --query "data center server rack" --count 3
    python3 fetch_image.py --style mckinsey --query "business team meeting" --count 1

Environment variables:
    UNSPLASH_ACCESS_KEY  - Unsplash API access key
    PEXELS_API_KEY       - Pexels API key
"""

import argparse
import os
import sys
import json
import requests
from urllib.parse import quote_plus

try:
    import requests
except ImportError:
    print("Error: requests is required. Install: pip install requests")
    sys.exit(1)


STYLE_KEYWORDS = {
    "spacex": ["rocket", "space launch", "industrial factory", "steel", "night sky", "horizon"],
    "nvidia": ["data center", "server rack", "chip", "GPU", "circuit board", "robot", "AI"],
    "mckinsey": ["business team", "data analysis", "strategy meeting", "city skyline", "technology"],
}


def build_query(style, user_query):
    """Combine style keywords with user query for better search results."""
    base = user_query.strip()
    # Avoid adding generic style keywords if the query is already specific
    if base and len(base.split()) >= 3:
        return base
    style_hints = " ".join(STYLE_KEYWORDS.get(style, []))
    return f"{base} {style_hints}".strip() if base else style_hints


def download_image(url, outdir, prefix, idx):
    """Download an image and return its local path."""
    os.makedirs(outdir, exist_ok=True)
    ext = ".jpg"
    # Try to infer extension from URL
    if ".png" in url.lower():
        ext = ".png"
    elif ".webp" in url.lower():
        ext = ".webp"
    local_path = os.path.join(outdir, f"{prefix}_{idx:02d}{ext}")
    try:
        r = requests.get(url, timeout=30)
        r.raise_for_status()
        with open(local_path, "wb") as f:
            f.write(r.content)
        return local_path
    except Exception as e:
        print(f"Failed to download {url}: {e}")
        return None


def search_unsplash(query, count, access_key):
    """Search Unsplash and return list of image dicts."""
    if not access_key:
        return []
    url = "https://api.unsplash.com/search/photos"
    headers = {"Authorization": f"Client-ID {access_key}"}
    params = {"query": query, "per_page": min(count, 30), "orientation": "landscape"}
    try:
        r = requests.get(url, headers=headers, params=params, timeout=30)
        r.raise_for_status()
        data = r.json()
        results = []
        for item in data.get("results", []):
            results.append({
                "source": "unsplash",
                "url": item["urls"]["raw"],
                "thumb": item["urls"]["small"],
                "author": item["user"]["name"],
                "author_url": item["user"]["links"]["html"],
                "description": item.get("description") or item.get("alt_description") or query,
            })
        return results
    except Exception as e:
        print(f"Unsplash API error: {e}")
        return []


def search_pexels(query, count, api_key):
    """Search Pexels and return list of image dicts."""
    if not api_key:
        return []
    url = "https://api.pexels.com/v1/search"
    headers = {"Authorization": api_key}
    params = {"query": query, "per_page": min(count, 80), "orientation": "landscape"}
    try:
        r = requests.get(url, headers=headers, params=params, timeout=30)
        r.raise_for_status()
        data = r.json()
        results = []
        for item in data.get("photos", []):
            results.append({
                "source": "pexels",
                "url": item["src"]["original"],
                "thumb": item["src"]["large"],
                "author": item["photographer"],
                "author_url": item["photographer_url"],
                "description": item.get("alt") or query,
            })
        return results
    except Exception as e:
        print(f"Pexels API error: {e}")
        return []


def search_fallback(query, style):
    """No API keys: print candidate search URLs for manual selection."""
    print(f"\nNo API keys found. Provide UNSPLASH_ACCESS_KEY or PEXELS_API_KEY to auto-download.")
    print(f"Style: {style}")
    print(f"Query: {query}")
    print("Candidate URLs:")
    print(f"  Unsplash: https://unsplash.com/s/photos/{quote_plus(query)}")
    print(f"  Pexels:   https://www.pexels.com/search/{quote_plus(query).replace('+', '%20')}/")
    return []


def main():
    parser = argparse.ArgumentParser(description="Fetch images for premium-ppt decks.")
    parser.add_argument("--style", required=True, choices=["spacex", "nvidia", "mckinsey"], help="Deck style")
    parser.add_argument("--query", required=True, help="Search query")
    parser.add_argument("--count", type=int, default=3, help="Number of images to fetch")
    parser.add_argument("--outdir", default="./images", help="Output directory")
    parser.add_argument("--prefix", default="slide", help="Filename prefix")
    parser.add_argument("--download", action="store_true", help="Download images (requires API keys)")
    args = parser.parse_args()

    query = build_query(args.style, args.query)
    unsplash_key = os.environ.get("UNSPLASH_ACCESS_KEY")
    pexels_key = os.environ.get("PEXELS_API_KEY")

    results = []
    if unsplash_key:
        results.extend(search_unsplash(query, args.count, unsplash_key))
    if pexels_key:
        results.extend(search_pexels(query, args.count, pexels_key))

    if not results:
        search_fallback(query, args.style)
        sys.exit(0)

    # Deduplicate by author+description and limit to count
    seen = set()
    unique = []
    for r in results:
        key = (r.get("author"), r.get("description"))
        if key not in seen:
            seen.add(key)
            unique.append(r)
            if len(unique) >= args.count:
                break

    manifest = []
    for idx, img in enumerate(unique, 1):
        if args.download:
            local_path = download_image(img["url"], args.outdir, args.prefix, idx)
            if local_path:
                img["local_path"] = local_path
        manifest.append(img)
        print(f"\n[{idx}] {img.get('description', 'image')}")
        print(f"    Source: {img['source']}")
        print(f"    Author: {img['author']} ({img['author_url']})")
        print(f"    URL:    {img['url']}")
        if "local_path" in img:
            print(f"    Local:  {img['local_path']}")

    # Save manifest
    manifest_path = os.path.join(args.outdir, f"{args.prefix}_manifest.json")
    os.makedirs(args.outdir, exist_ok=True)
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
    print(f"\nManifest saved to {manifest_path}")


if __name__ == "__main__":
    main()
