#!/usr/bin/env python3
"""
Build a keynote-style PPTX deck from a JSON config and a selected style.

Usage:
    python3 build_deck.py --style spacex --config deck_config.json --out deck.pptx
    python3 build_deck.py --style nvidia --config deck_config.json --out deck.pptx
    python3 build_deck.py --style mckinsey --config deck_config.json --out deck.pptx

Config format (JSON):
{
  "title": "Deck Title",
  "slides": [
    {
      "type": "cover",
      "title": "MISSION TO MARS",
      "subtitle": "Series A Roadshow",
      "image": "images/slide_01.jpg"
    },
    {
      "type": "metric_grid",
      "title": "N OF 1: THE INFRASTRUCTURE OF THE FUTURE",
      "columns": [
        {"label": "SPACE", "metrics": [{"value": "~650", "unit": "TOTAL LAUNCHES"}]},
        {"label": "CONNECTIVITY", "metrics": [{"value": "9,600+", "unit": "STARLINK SATELLITES"}]},
        {"label": "AI", "metrics": [{"value": "~1.0GW", "unit": "COMPUTE DRAW"}]}
      ],
      "image": "images/slide_02.jpg"
    }
  ]
}
"""

import argparse
import json
import os
import sys
import tempfile
from io import BytesIO

try:
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
    from pptx.dml.color import RGBColor
    from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
except ImportError:
    print("Error: python-pptx is required. Install: pip install python-pptx")
    sys.exit(1)

try:
    from PIL import Image, ImageDraw
except ImportError:
    Image = None
    ImageDraw = None


DESIGN_SYSTEMS = {
    "spacex": {
        "canvas": (0, 0, 0),
        "headline": (255, 255, 255),
        "body": (184, 184, 184),
        "muted": (112, 112, 112),
        "rule": (64, 64, 64),
       "accent": (255, 255, 255),
        "font": "PingFang SC",
        "title_case": "uppercase",
    },
    "nvidia": {
        "canvas": (0, 0, 0),
        "headline": (255, 255, 255),
        "body": (184, 184, 184),
        "muted": (128, 128, 128),
        "rule": (64, 64, 64),
        "accent": (118, 185, 0),
       "accent_secondary": (212, 175, 55),
        "font": "PingFang SC",
        "title_case": "sentence",
    },
    "mckinsey": {
        "canvas": (255, 255, 255),
        "headline": (51, 51, 51),
        "body": (85, 85, 85),
        "muted": (136, 136, 136),
        "rule": (204, 204, 204),
        "accent": (0, 102, 177),
       "accent_light": (230, 240, 248),
        "font": "PingFang SC",
        "title_case": "sentence",
    },
}


SLIDE_WIDTH = Inches(13.333)
SLIDE_HEIGHT = Inches(7.5)
MARGIN_LEFT = Inches(0.6)
MARGIN_RIGHT = Inches(0.6)
MARGIN_TOP = Inches(0.5)
MARGIN_BOTTOM = Inches(0.5)


def set_slide_bg(slide, rgb):
    """Set solid background color for a slide."""
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(*rgb)


def add_textbox(slide, left, top, width, height, text, font_size, rgb, bold=False, font="Arial", align=PP_ALIGN.LEFT):
    """Add a text box with given styling."""
    box = slide.shapes.add_textbox(left, top, width, height)
    tf = box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.alignment = align
    run = p.runs[0]
    run.font.size = Pt(font_size)
    run.font.bold = bold
    run.font.color.rgb = RGBColor(*rgb)
    run.font.name = font
    return box


def gradient_mask(size, anchor, alpha):
    """Create a grayscale mask where the text area is darkest."""
    w, h = size
    mask = Image.new('L', (w, h))
    draw = ImageDraw.Draw(mask)
    max_val = int(alpha * 255)
    if anchor == 'bottom':
        for y in range(h):
            v = int(max_val * (y / (h - 1)))
            draw.line([(0, y), (w, y)], fill=v)
    elif anchor == 'top':
        for y in range(h):
            v = int(max_val * (1 - y / (h - 1)))
            draw.line([(0, y), (w, y)], fill=v)
    elif anchor == 'left':
        for x in range(w):
            v = int(max_val * (1 - x / (w - 1)))
            draw.line([(x, 0), (x, h)], fill=v)
    elif anchor == 'right':
        for x in range(w):
            v = int(max_val * (x / (w - 1)))
            draw.line([(x, 0), (x, h)], fill=v)
    else:
        draw.rectangle([0, 0, w, h], fill=max_val)
    return mask


def apply_overlay(path, overlay_rgb, overlay_alpha=0.5, target_width=1920, target_height=1080, anchor='center'):
    """Pre-composite a directional dark overlay onto an image so text stays readable."""
def apply_uniform_overlay(path, overlay_rgb, overlay_alpha=0.25):
    """Apply a uniform dark overlay to an image without cropping to 16:9."""
    if not Image:
        return path
    img = Image.open(path).convert("RGB")
    overlay = Image.new("RGB", img.size, overlay_rgb)
    blended = Image.blend(img, overlay, overlay_alpha)
    out = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
    blended.save(out.name, quality=95)
    return out.name

def apply_overlay(path, overlay_rgb, overlay_alpha=0.5, target_width=1920, target_height=1080, anchor='center'):
    """Pre-composite a directional dark overlay onto an image so text stays readable."""
    if not Image:
        return path
    img = Image.open(path).convert("RGB")
    src_w, src_h = img.size
    target_ratio = target_width / target_height
    src_ratio = src_w / src_h
    if src_ratio > target_ratio:
        new_w = int(src_h * target_ratio)
        left = (src_w - new_w) // 2
        img = img.crop((left, 0, left + new_w, src_h))
    else:
        new_h = int(src_w / target_ratio)
        top = (src_h - new_h) // 2
        img = img.crop((0, top, src_w, top + new_h))
    lanczos = getattr(Image.Resampling, "LANCZOS", Image.LANCZOS)
    img = img.resize((target_width, target_height), lanczos)
    overlay = Image.new("RGB", (target_width, target_height), overlay_rgb)
    mask = gradient_mask((target_width, target_height), anchor, overlay_alpha)
    composited = Image.composite(overlay, img, mask)
    out = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
    composited.save(out.name, quality=95)
    return out.name


def add_full_bleed_image(slide, path, overlay_rgb=None, overlay_alpha=0.5, anchor='center'):
    """Add a full-bleed image with optional dark overlay."""
    if not path or not os.path.exists(path):
        return None
    if overlay_rgb:
        path = apply_overlay(path, overlay_rgb, overlay_alpha, anchor=anchor)
    pic = slide.shapes.add_picture(path, Inches(0), Inches(0), width=SLIDE_WIDTH, height=SLIDE_HEIGHT)
    # Send to back so it sits behind text
    slide.shapes._spTree.remove(pic._element)
    slide.shapes._spTree.insert(2, pic._element)
    return pic


def add_line(slide, x1, y1, x2, y2, rgb, width=1):
    """Add a simple line."""
    line = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, x1, y1, x2, y2)
    line.line.color.rgb = RGBColor(*rgb)
    line.line.width = Pt(width)
    return line


def build_cover(slide, ds, data):
    set_slide_bg(slide, ds["canvas"])
    if data.get("image"):
        add_full_bleed_image(slide, data["image"], ds["canvas"], 0.5, anchor='bottom')
    title = data.get("title", "")
    subtitle = data.get("subtitle", "")
    add_textbox(slide, MARGIN_LEFT, Inches(4.0), Inches(10), Inches(2.0), title, 48, ds["headline"], bold=True, font=ds["font"])
    if subtitle:
        add_textbox(slide, MARGIN_LEFT, Inches(6.2), Inches(10), Inches(0.6), subtitle, 20, ds["body"], font=ds["font"])


def build_section(slide, ds, data):
    set_slide_bg(slide, ds["canvas"])
    if data.get("image"):
        add_full_bleed_image(slide, data["image"], ds["canvas"], 0.4, anchor='bottom')
    title = data.get("title", "")
    add_textbox(slide, MARGIN_LEFT, Inches(5.5), Inches(10), Inches(1.0), title, 44, ds["headline"], bold=True, font=ds["font"])


def build_title_content(slide, ds, data):
    set_slide_bg(slide, ds["canvas"])
    if data.get("image"):
        add_full_bleed_image(slide, data["image"], ds["canvas"], 0.5, anchor='top')
    title = data.get("title", "")
    bullets = data.get("bullets", [])
    add_textbox(slide, MARGIN_LEFT, MARGIN_TOP, Inches(10), Inches(0.8), title, 32, ds["headline"], bold=True, font=ds["font"])
    y = Inches(1.5)
    for b in bullets:
        add_textbox(slide, MARGIN_LEFT, y, Inches(11), Inches(0.6), b, 18, ds["body"], font=ds["font"])
        y += Inches(0.7)


def build_metric_grid(slide, ds, data):
    set_slide_bg(slide, ds["canvas"])
    if data.get("image"):
        add_full_bleed_image(slide, data["image"], ds["canvas"], 0.5, anchor='top')
    title = data.get("title", "")
    add_textbox(slide, MARGIN_LEFT, MARGIN_TOP, Inches(11), Inches(0.8), title, 36, ds["headline"], bold=True, font=ds["font"])
    cols = data.get("columns", [])
    n = len(cols) if cols else 1
    col_width = Inches(11.0 / n)
    x = MARGIN_LEFT
    y = Inches(1.5)
    for col in cols:
        add_textbox(slide, x, y, col_width, Inches(0.4), col.get("label", "").upper(), 16, ds["accent"], bold=True, font=ds["font"])
        add_line(slide, x, y + Inches(0.45), x + col_width - Inches(0.1), y + Inches(0.45), ds["rule"])
        my = y + Inches(0.6)
        for m in col.get("metrics", []):
            add_textbox(slide, x, my, col_width, Inches(0.5), m.get("value", ""), 32, ds["headline"], bold=True, font=ds["font"])
            add_textbox(slide, x, my + Inches(0.45), col_width, Inches(0.3), m.get("unit", ""), 12, ds["muted"], font=ds["font"])
            my += Inches(0.9)
        x += col_width


def build_image_text(slide, ds, data):
    set_slide_bg(slide, ds["canvas"])
    title = data.get("title", "")
    bullets = data.get("bullets", [])
    image = data.get("image")
    image_pos = data.get("image_position", "right")
    if image and ds.get("canvas") and os.path.exists(image):
        image = apply_uniform_overlay(image, ds["canvas"], 0.25)
    add_textbox(slide, MARGIN_LEFT, MARGIN_TOP, Inches(11), Inches(0.8), title, 32, ds["headline"], bold=True, font=ds["font"])
    y = Inches(1.5)
    text_width = Inches(5.5)
    text_left = MARGIN_LEFT if image_pos == "right" else Inches(6.8)
    img_left = Inches(6.8) if image_pos == "right" else MARGIN_LEFT
    for b in bullets:
        add_textbox(slide, text_left, y, text_width, Inches(0.6), b, 18, ds["body"], font=ds["font"])
        y += Inches(0.7)
    if image and os.path.exists(image):
        slide.shapes.add_picture(image, img_left, Inches(1.5), width=Inches(5.5))


def build_ask(slide, ds, data):
    set_slide_bg(slide, ds["canvas"])
    if data.get("image"):
        add_full_bleed_image(slide, data["image"], ds["canvas"], 0.4, anchor='center')
    title = data.get("title", "")
    ask = data.get("ask", "")
    add_textbox(slide, MARGIN_LEFT, Inches(2.5), Inches(11), Inches(1.0), title, 40, ds["headline"], bold=True, font=ds["font"])
    add_textbox(slide, MARGIN_LEFT, Inches(3.8), Inches(11), Inches(1.0), ask, 24, ds["accent"], bold=True, font=ds["font"])


BUILDERS = {
    "cover": build_cover,
    "section": build_section,
    "title_content": build_title_content,
    "metric_grid": build_metric_grid,
    "image_text": build_image_text,
    "ask": build_ask,
}


def main():
    parser = argparse.ArgumentParser(description="Build a keynote-style PPTX deck.")
    parser.add_argument("--style", required=True, choices=DESIGN_SYSTEMS.keys(), help="Visual style")
    parser.add_argument("--config", required=True, help="Path to JSON deck config")
    parser.add_argument("--out", required=True, help="Output PPTX path")
    args = parser.parse_args()

    if not os.path.exists(args.config):
        print(f"Config not found: {args.config}")
        sys.exit(1)

    out_dir = os.path.dirname(os.path.abspath(args.out))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    with open(args.config, "r", encoding="utf-8") as f:
        config = json.load(f)

    ds = DESIGN_SYSTEMS[args.style]
    prs = Presentation()
    prs.slide_width = SLIDE_WIDTH
    prs.slide_height = SLIDE_HEIGHT

    blank_layout = prs.slide_layouts[6]  # blank

    for slide_data in config.get("slides", []):
        slide_type = slide_data.get("type", "title_content")
        builder = BUILDERS.get(slide_type)
        if not builder:
            print(f"Warning: unknown slide type {slide_type}, skipping.")
            continue
        slide = prs.slides.add_slide(blank_layout)
        builder(slide, ds, slide_data)

    prs.save(args.out)
    print(f"Saved {args.out} ({len(prs.slides)} slides, style={args.style})")


if __name__ == "__main__":
    main()
