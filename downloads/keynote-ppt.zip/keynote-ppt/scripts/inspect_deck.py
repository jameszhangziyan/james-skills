#!/usr/bin/env python3
"""
Inspect a keynote-style PPTX deck and produce a QA report with rendered thumbnails.

Usage:
    python3 inspect_deck.py --pptx tests/output_spacex.pptx --style spacex --outdir tests/qa_spacex

Requires:
    - python-pptx
    - PyMuPDF (fitz) for LibreOffice-rendered thumbnails
    - LibreOffice (soffice) for PPTX -> PDF conversion
    - Pillow for proxy thumbnails when LibreOffice is unavailable
"""

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import math
from pathlib import Path

try:
    from pptx import Presentation
    from pptx.util import Emu, Inches, Pt
except ImportError:
    print("Error: python-pptx is required. Install: pip install python-pptx")
    sys.exit(1)

try:
    from PIL import Image, ImageDraw, ImageFont
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

try:
    import fitz  # PyMuPDF
    HAS_FITZ = True
except ImportError:
    HAS_FITZ = False


SLIDE_WIDTH_PT = 960.0
SLIDE_HEIGHT_PT = 540.0
MARGIN_PT = 36.0
MAX_TEXT_PER_SLIDE = 120
MAX_BULLETS_PER_SLIDE = 6
MAX_TITLE_LEN = 90
EMU_PER_PT = 12700
CHAR_WIDTH_FACTOR = 0.55
LINE_HEIGHT_FACTOR = 1.2


def emu_to_pt(emu):
    return emu / EMU_PER_PT if emu else 0


def pt_to_px(pt, dpi=96):
    return pt * (dpi / 72.0)


def convert_to_pdf(pptx_path, outdir):
    """Convert PPTX to PDF using LibreOffice if available."""
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        raise RuntimeError("LibreOffice (soffice) not found.")
    pptx_path = Path(pptx_path).resolve()
    outdir = Path(outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    profile = Path("/tmp") / f"lo_profile_{os.getpid()}"
    cmd = [
        soffice,
        "--headless",
        "-env:UserInstallation=file:///" + str(profile).replace("/", ""),
        "--convert-to",
        "pdf",
        "--outdir",
        str(outdir),
        str(pptx_path),
    ]
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    except subprocess.TimeoutExpired:
        raise RuntimeError("LibreOffice PDF conversion timed out.")
    pdf_name = pptx_path.stem + ".pdf"
    pdf_path = outdir / pdf_name
    if not pdf_path.exists():
        raise RuntimeError(f"PDF conversion failed: {pdf_path} not created.")
    return pdf_path


def render_thumbnails(pdf_path, thumbdir, width=1280):
    """Render PDF pages to PNG thumbnails using PyMuPDF."""
    if not HAS_FITZ:
        raise RuntimeError("PyMuPDF is not available.")
    thumbdir = Path(thumbdir)
    thumbdir.mkdir(parents=True, exist_ok=True)
    doc = fitz.open(str(pdf_path))
    paths = []
    for i in range(len(doc)):
        page = doc.load_page(i)
        zoom = width / page.rect.width
        mat = fitz.Matrix(zoom, zoom)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        img_path = thumbdir / f"slide_{i+1:02d}.png"
        pix.save(str(img_path))
        paths.append(str(img_path))
    doc.close()
    return paths


def render_proxy_thumbnails(pptx_path, thumbdir, width=1280):
    """Render a readable proxy thumbnail from python-pptx when LibreOffice fails."""
    if not HAS_PIL:
        raise RuntimeError("Pillow is not available; cannot render proxy thumbnails.")
    thumbdir = Path(thumbdir)
    thumbdir.mkdir(parents=True, exist_ok=True)
    prs = Presentation(str(pptx_path))
    scale = width / SLIDE_WIDTH_PT
    height = int(SLIDE_HEIGHT_PT * scale)
    try:
        font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 16)
    except Exception:
        try:
            font = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 16)
        except Exception:
            font = ImageFont.load_default()
    paths = []
    for idx, slide in enumerate(prs.slides):
        img = Image.new("RGB", (width, height), (255, 255, 255))
        draw = ImageDraw.Draw(img)
        bg = get_background_color(slide)
        if bg:
            draw.rectangle([0, 0, width, height], fill=bg)
        for shape in slide.shapes:
            left = int(emu_to_pt(shape.left) * scale)
            top = int(emu_to_pt(shape.top) * scale)
            w = int(emu_to_pt(shape.width) * scale)
            h = int(emu_to_pt(shape.height) * scale)
            if shape.shape_type == 13:  # picture
                draw.rectangle([left, top, left + w, top + h], outline=(0, 200, 0), width=2)
                draw.text((left + 4, top + 4), "[IMG]", fill=(0, 200, 0), font=font)
            elif shape.has_text_frame:
                text = "\n".join(p.text for p in shape.text_frame.paragraphs if p.text).strip()
                if text:
                    # choose a contrasting color
                    bright = brightness(bg) if bg else 255
                    fill = (0, 0, 0) if bright > 120 else (255, 255, 255)
                    draw.rectangle([left, top, left + w, top + h], outline=(128, 128, 128), width=1)
                    draw.text((left + 2, top + 2), text[:300], fill=fill, font=font)
        # slide number
        draw.text((width - 40, height - 24), f"{idx+1}", fill=(200, 0, 0), font=font)
        img_path = thumbdir / f"slide_{idx+1:02d}.png"
        img.save(img_path)
        paths.append(str(img_path))
    return paths


def extract_text_runs(slide):
    """Extract all non-empty text snippets from a slide."""
    results = []
    for shape in slide.shapes:
        if shape.has_text_frame:
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    text = run.text.strip()
                    if text:
                        results.append(text)
    return results


def count_images(slide):
    """Count picture shapes on a slide."""
    return sum(1 for shape in slide.shapes if shape.shape_type == 13)


def get_background_color(slide):
    """Return RGB tuple of the slide background if solid."""
    try:
        fill = slide.background.fill
        if fill.type == 1:  # MSO_FILL.SOLID
            rgb = fill.fore_color.rgb
            return (rgb[0], rgb[1], rgb[2])
    except Exception:
        pass
    return None


def brightness(rgb):
    """Relative luminance (0-255)."""
    if not rgb:
        return 128
    r, g, b = rgb
    return 0.299 * r + 0.587 * g + 0.114 * b


def text_overflow_warnings(slide):
    """Detect shapes whose text is likely too wide or too tall for the box."""
    warnings = []
    for shape in slide.shapes:
        if not shape.has_text_frame:
            continue
        box_w = emu_to_pt(shape.width)
        box_h = emu_to_pt(shape.height)
        if box_w <= 0 or box_h <= 0:
            continue
        full_text = " ".join(p.text for p in shape.text_frame.paragraphs if p.text).strip()
        if not full_text:
            continue
        # Approximate font size from first run, default 18
        font_size = 18
        for para in shape.text_frame.paragraphs:
            if para.runs:
                try:
                    size = para.runs[0].font.size
                    if size is not None:
                        font_size = max(8, size.pt)
                except Exception:
                    pass
                break
        text_width = len(full_text) * font_size * CHAR_WIDTH_FACTOR
        line_height = font_size * LINE_HEIGHT_FACTOR
        if text_width > box_w * 1.05 and not shape.text_frame.word_wrap:
            warnings.append(f"Text may overflow horizontally in a {font_size:.0f}pt box.")
        elif text_width > box_w * 1.5:
            # Even with wrapping, estimate whether it fits vertically
            lines = max(1, math.ceil(text_width / box_w))
            if lines * line_height > box_h * 1.05:
                warnings.append(f"Text may be clipped vertically ({lines} estimated lines in {box_h:.0f}pt box).")
    return warnings


def inspect_slide(idx, slide, style=None):
    """Build a QA dict for one slide."""
    warnings = []
    runs = extract_text_runs(slide)
    full_text = " ".join(runs)
    image_count = count_images(slide)
    bg = get_background_color(slide)
    bg_bright = brightness(bg)
    title = runs[0] if runs else ""

    if len(full_text) > MAX_TEXT_PER_SLIDE * 6:
        warnings.append("Slide is very text-dense; consider breaking into two slides.")
    if len(runs) > MAX_BULLETS_PER_SLIDE + 2:
        warnings.append("Too many distinct text blocks/bullets; simplify hierarchy.")
    if len(title) > MAX_TITLE_LEN:
        warnings.append("Title is long; make it a punchier conclusion.")
    if not title:
        warnings.append("No title found.")
    if style in ("spacex", "nvidia") and image_count == 0:
        warnings.append("Dark/cinematic styles usually need a visual anchor.")
    if style == "mckinsey" and image_count > 1:
        warnings.append("McKinsey style should minimize images; one concept image is enough.")
    if bg_bright < 40 and image_count == 0:
        warnings.append("Dark background with no image may look empty; consider a background image or texture.")
    warnings.extend(text_overflow_warnings(slide))
    return {
        "slide": idx + 1,
        "title": title[:120],
        "text_blocks": len(runs),
        "word_count": len(re.findall(r"\b\w+\b", full_text)),
        "image_count": image_count,
        "background_rgb": bg,
        "warnings": warnings,
    }


def inspect_pptx(pptx_path, style):
    prs = Presentation(str(pptx_path))
    return [inspect_slide(i, slide, style) for i, slide in enumerate(prs.slides)]


def main():
    parser = argparse.ArgumentParser(description="Inspect a keynote-style PPTX deck.")
    parser.add_argument("--pptx", required=True, help="Path to PPTX file")
    parser.add_argument("--style", choices=["spacex", "nvidia", "mckinsey"], help="Optional style for style-specific checks")
    parser.add_argument("--outdir", required=True, help="Directory for QA report and thumbnails")
    parser.add_argument("--width", type=int, default=1280, help="Thumbnail width in pixels")
    args = parser.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    style = args.style or infer_style(args.pptx)
    slides = inspect_pptx(args.pptx, style)

    thumbs = []
    try:
        pdf_path = convert_to_pdf(args.pptx, outdir)
        thumbs = render_thumbnails(pdf_path, outdir / "thumbnails", width=args.width)
        pdf_path.unlink()
    except Exception as e:
        # Fallback: generate proxy thumbnails from python-pptx structure
        try:
            thumbs = render_proxy_thumbnails(args.pptx, outdir / "thumbnails", width=args.width)
        except Exception as e2:
            slides.append({
                "slide": "QA system",
                "warnings": [f"LibreOffice failed: {e}", f"Proxy thumbnail fallback also failed: {e2}"],
            })

    report = {
        "pptx": str(Path(args.pptx).resolve()),
        "style": style,
        "slide_count": len(slides),
        "thumbnails": thumbs,
        "slides": slides,
    }
    report_path = outdir / "qa_report.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    total_warnings = sum(len(s.get("warnings", [])) for s in slides if isinstance(s.get("slide"), int))
    print(f"Inspected {report['slide_count']} slides ({style} style)")
    print(f"Thumbnails: {len(thumbs)} saved to {outdir / 'thumbnails'}")
    print(f"Report: {report_path}")
    if total_warnings:
        print(f"Warnings: {total_warnings}")
        for s in slides:
            if isinstance(s.get("slide"), int) and s.get("warnings"):
                for w in s["warnings"]:
                    print(f"  Slide {s['slide']}: {w}")
    else:
        print("No warnings.")


def infer_style(pptx_path):
    name = Path(pptx_path).stem.lower()
    if "nvidia" in name:
        return "nvidia"
    if "mckinsey" in name:
        return "mckinsey"
    return "spacex"


if __name__ == "__main__":
    main()
