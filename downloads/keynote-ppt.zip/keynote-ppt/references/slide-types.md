# Slide Type Library

This file defines reusable slide types. Each type has a layout job, a content pattern, and style-specific notes. The `build_deck.py` script reads the selected `design-system-<style>.md` and this file to place content.

## Cover

- **Job**: Establish brand/title, set tone immediately.
- **Layout**: Full-bleed background image (SpaceX/NVIDIA) or clean white canvas (McKinsey). Title lower-left or centered. Subtitle/date below. No bullet points.
- **Image**: Yes (background). Search keywords: rocket launch, data center, industrial, arena, chip.
- **Style notes**:
  - SpaceX: planet/space image, white title, small logo.
  - NVIDIA: black background, logo centered, optional arena photo.
  - McKinsey: white background, minimal title, no image or a small clean icon.

## Section Divider

- **Job**: Transition to a new chapter.
- **Layout**: Full-bleed image (SpaceX/NVIDIA) or large blue title (McKinsey). One big word or short phrase.
- **Image**: Yes (background for dark styles).
- **Style notes**:
  - SpaceX/NVIDIA: cinematic photo, title in lower-left.
  - McKinsey: white background, blue section title, thin rule below.

## Stakes

- **Job**: Why care now? Establish the costly status quo or ambition.
- **Layout**: One large scale metric or consequence. Optional supporting image.
- **Image**: Optional (background or side image for dark styles; small icon for McKinsey).
- **Style notes**:
  - SpaceX: full-bleed image + large white number.
  - NVIDIA: product/context image + bold statement.
  - McKinsey: chart or fact box with source.

## Friction

- **Job**: Name the constraint, bottleneck, or asymmetry.
- **Layout**: Split screen or 2-column: problem statement + evidence.
- **Image**: Optional.
- **Style notes**:
  - SpaceX: minimal text over dark image.
  - NVIDIA: diagram showing the bottleneck.
  - McKinsey: bullet points with data, action title states the problem.

## Insight / Turning Point

- **Job**: Reveal the non-obvious causal insight or decisive asset.
- **Layout**: Central concept + supporting bullets.
- **Image**: Yes (diagram or schematic).
- **Style notes**:
  - SpaceX: product image + callout labels.
  - NVIDIA: architecture diagram or product spec image.
  - McKinsey: driver tree or framework diagram.

## Proof

- **Job**: Convert thesis into verified performance.
- **Layout**: 1–3 traceable numbers, not a metric wall. Chart or metric cards.
- **Image**: Optional (chart image or small icon).
- **Style notes**:
  - SpaceX: metric grid with horizontal rules.
  - NVIDIA: performance chart or spec list.
  - McKinsey: chart with source footer.

## Product / System

- **Job**: Show the solution, system, or product.
- **Layout**: Large product/system image + callouts or specs.
- **Image**: Yes (product photo or diagram).
- **Style notes**:
  - SpaceX: full-height product image on right, text on left.
  - NVIDIA: product image + chip diagrams + specs.
  - McKinsey: process diagram or system flowchart.

## Market / Opportunity

- **Job**: Quantify the upside.
- **Layout**: TAM/SAM/SOM or market growth chart.
- **Image**: Optional.
- **Style notes**:
  - SpaceX/NVIDIA: large number + supporting chart over dark background.
  - McKinsey: waterfall or bar chart with detailed source.

## Roadmap

- **Job**: Show the path forward.
- **Layout**: Timeline or phase columns.
- **Image**: No.
- **Style notes**:
  - SpaceX/NVIDIA: minimal timeline with milestone dots.
  - McKinsey: detailed phase table with owners and dates.

## Ask / Closing

- **Job**: Make one precise decision request.
- **Layout**: Big headline + one ask. No distractions.
- **Image**: Optional subtle background (SpaceX/NVIDIA) or none (McKinsey).
- **Style notes**:
  - SpaceX/NVIDIA: black background, large white text.
  - McKinsey: white background, action title, 3–4 next steps.

## Credits / Source

- **Job**: Attribute images and data sources.
- **Layout**: Small text list, clean.
- **Image**: No.
- **Style notes**: All styles: minimal, readable, at the end or in appendix.
