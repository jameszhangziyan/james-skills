# SpaceX-Inspired Design System

# Industrial Roadshow / Mission-Led Presentation

## Visual Tokens

```yaml
canvas: "#000000"
headline: "#FFFFFF"
body: "#B8B8B8"
muted: "#707070"
rule: "#404040"
accent: "#FFFFFF"        # SpaceX uses monochrome; accent is white
overlay_start: "#000000" # gradient over full-bleed images
overlay_end: "#00000000" # transparent
font_stack: "Arial Narrow, Aptos Narrow, Helvetica Neue Condensed, sans-serif"
title_case: "uppercase"
ratio: "16:9"
margin_left: "0.6in"
margin_right: "0.6in"
margin_top: "0.5in"
margin_bottom: "0.5in"
```

## Typography Scale

| Element | Size | Weight | Color | Case |
|---------|------|--------|-------|------|
| Cover title | 44–54 pt | Regular | `#FFFFFF` | Sentence or title case |
| Section headline | 36–48 pt | Bold | `#FFFFFF` | UPPERCASE |
| Metric number | 48–72 pt | Bold | `#FFFFFF` | - |
| Metric unit | 18–24 pt | Regular | `#B8B8B8` | UPPERCASE |
| Body / bullet | 18–24 pt | Regular | `#B8B8B8` | Sentence |
| Label / caption | 12–14 pt | Regular | `#707070` | UPPERCASE |
| Page number | 10 pt | Regular | `#707070` | - |

## Layout Patterns

### Cover
- Full-bleed industrial/space image with bottom gradient fading to black.
- SpaceX-style logo centered near top (use placeholder, not official logo).
- Title at lower-left, date below title in muted gray.

### Metric Grid
- Three columns, each with a section label (UPPERCASE, rule below).
- 2–3 metric rows per column, separated by horizontal rules (`#404040`, 0.5 pt).
- Large number left, unit right or below.
- Optional full-bleed image at bottom 20–30% of slide.

### Product / System
- Left 40–50%: text list with horizontal rules between items.
- Right 50–60%: full-height product image.
- Callout labels with thin leader lines pointing to features.

### Team / People
- Row of 3 black-and-white portrait photos, evenly spaced.
- Names in UPPERCASE small label below each photo.
- Right side: metric cards with horizontal rules and large numbers.

### Section Divider
- Full-bleed industrial/space image.
- Title in lower-left, minimal subtitle.

### Ask / Closing
- Black background, no image or subtle texture.
- Large centered or left-aligned headline.
- One concrete ask below (amount, timeline, owner).

## Image Treatment

- Full-bleed photography only. No clip art, no stock people shaking hands.
- Keywords: rocket, launch pad, factory floor, welding, engine, satellite, night sky, horizon, industrial steel, clean room, workers at scale.
- Apply gradient overlay so text in lower-left or left third is readable.
- Use a dark vignette if needed.
- Convert portraits to black and white.

## Chart Style

- Background: black.
- Axes: `#707070` thin lines.
- Data lines: `#FFFFFF` or `#B8B8B8`.
- Highlight: white only.
- No 3D, no shadows, no grid unless necessary.

## Do Not

- Use colored blocks, gradient backgrounds, or decorative shapes.
- Add shadows, glows, or 3D effects.
- Center-align body text.
- Use more than one accent color.
- Put a horizontal rule across the top of the slide.

## Notes

- SpaceX is monochrome. Contrast and typography carry the hierarchy, not color.
- Every number needs a unit and a source in presenter notes.
*** Add File: /Users/james/note/premium-ppt/references/design-system-nvidia.md
# NVIDIA-Inspired Design System

# Keynote / Cinematic AI Infrastructure Presentation

## Visual Tokens

```yaml
canvas: "#000000"
headline: "#FFFFFF"
body: "#B8B8B8"
muted: "#808080"
accent: "#76B900"       # NVIDIA green
accent_secondary: "#D4AF37"  # gold for highlights / multiples
accent_tertiary: "#4A90E2"   # optional partner/tech blue
overlay: "#000000"      # used at 40–60% opacity over images
font_stack: "Arial, Aptos, Helvetica Neue, sans-serif"
title_case: "sentence"
ratio: "16:9"
margin_left: "0.6in"
margin_right: "0.6in"
margin_top: "0.5in"
margin_bottom: "0.5in"
```

## Typography Scale

| Element | Size | Weight | Color | Case |
|---------|------|--------|-------|------|
| Cover / big statement | 48–72 pt | Bold | `#FFFFFF` | Sentence |
| Section headline | 36–44 pt | Bold | `#FFFFFF` | Sentence |
| Subhead / quote | 24–32 pt | Regular | `#FFFFFF` or `#76B900` | Sentence |
| Metric / spec | 24–36 pt | Bold | `#FFFFFF` or `#76B900` | - |
| Body | 18–24 pt | Regular | `#B8B8B8` | Sentence |
| Label | 14–16 pt | Regular | `#808080` | UPPERCASE or Sentence |
| Caption / source | 12–14 pt | Regular | `#808080` | Sentence |

## Layout Patterns

### Cover
- Pure black background.
- NVIDIA-style logo centered (use placeholder, not official logo).
- Optional: full-bleed arena/audience photo with dark overlay, event title top-left.

### Trend / Evolution
- Black canvas.
- One large glowing green arrow/curve from left to right.
- Stages labeled in green or white along the curve.
- Small line-art icons at each stage.

### Product Spec
- Left 40%: full-height product photo (server rack, chip, hardware).
- Center 40%: title + specs, with green numbers for multiples (X).
- Right 20%: small chip/component images with labels.

### Architecture Diagram
- Title at top, centered or left-aligned.
- Dark rounded-rectangle cards with thin border (`#404040` or `#76B900` glow).
- Icons inside cards, connected by thin lines or arrows.
- Green/yellow accent for NVIDIA components, blue/white for partners.

### Chart / Performance
- Black background.
- Light axes (`#808080`).
- Data lines: `#76B900`, `#D4AF37`, `#FFFFFF`.
- Labels directly on the curve or near data points.

### Customer / Partner
- Partner logo on left (use placeholder).
- Large system diagram on right in dark card.
- Thin colored lines to show data flow.

### Quote / Press
- Full-bleed image or cinematic photo.
- Large quote in white, source below in gray.
- Optional green quote mark.

## Image Treatment

- Keywords: data center, GPU, server rack, chip, silicon wafer, factory, robot, autonomous vehicle, arena, stage lights, circuit board, neural network, glowing green lines.
- Full-bleed hardware photos with dramatic lighting.
- Product images should have dark background or be isolated on black.
- Architecture diagrams should have glowing edges, not flat shadows.

## Chart Style

- Background: black.
- Axes: `#808080`.
- Lines: `#76B900` for primary, `#D4AF37` for secondary, `#FFFFFF` for baseline.
- Data points: white or green dots.
- Avoid grid lines unless faint (`#333333`).

## Do Not

- Use McKinsey-style white backgrounds.
- Use decorative gradients or colored blocks.
- Overuse green: green is for accent only (logo, arrows, multiples, key labels).
- Put dense paragraphs on slides.

## Notes

- NVIDIA green is the signature. Use it sparingly so it has impact.
- The deck should feel like a stage keynote: big visuals, big numbers, minimal text.
*** Add File: /Users/james/note/premium-ppt/references/design-system-mckinsey.md
# McKinsey-Inspired Design System

# Consulting / Strategy / Analytical Presentation

## Visual Tokens

```yaml
canvas: "#FFFFFF"
headline: "#333333"
body: "#555555"
muted: "#888888"
rule: "#CCCCCC"
accent: "#0066B1"        # McKinsey blue
accent_light: "#E6F0F8"  # light blue for fills
highlight: "#F3F3F3"      # light gray for alternating fills
font_stack: "Arial, Aptos, Calibri, Helvetica Neue, sans-serif"
title_case: "sentence"
ratio: "16:9"
margin_left: "0.6in"
margin_right: "0.6in"
margin_top: "0.5in"
margin_bottom: "0.5in"
```

## Typography Scale

| Element | Size | Weight | Color | Case |
|---------|------|--------|-------|------|
| Action title | 24–32 pt | Bold | `#333333` | Sentence |
| Section header | 20–24 pt | Bold | `#0066B1` | Sentence |
| Body | 14–18 pt | Regular | `#555555` | Sentence |
| Chart label | 12–14 pt | Regular | `#555555` | Sentence |
| Source / footer | 10–12 pt | Regular | `#888888` | Sentence |
| Page number | 10 pt | Regular | `#888888` | - |

## Layout Patterns

### Executive Summary
- Title: full-sentence conclusion.
- 3–4 supporting bullets below, each with a key number or fact.
- Optional chart or icon on right.

### Driver Tree / Issue Tree
- Top-down decomposition of a metric.
- Boxes connected by lines, arithmetic shown.
- Color: blue for primary metric, gray for sub-metrics.

### Waterfall Chart
- Bridge from baseline to target.
- Green/blue for positive drivers, red/orange for negative.
- Source footer below.

### 2x2 Matrix
- Two axes, four quadrants.
- Blue dots or labels for options/competitors.
- Clear quadrant labels.

### Roadmap / Plan
- Timeline columns: phase, owner, milestone, deliverable.
- Blue for active/initiatives, gray for future.

### Chart / Data
- White background, gray axes, blue bars/lines.
- Data labels directly on bars.
- Source footer mandatory.

### Ask / Next Steps
- White background.
- Title: recommended action.
- 3–4 concrete steps with owner and timeline.

## Image Treatment

- Images are rarely used. When needed, use simple icons, small photos, or conceptual visuals.
- Keywords: abstract business, teamwork, data analysis, city skyline, technology (use sparingly).
- If a photo is used, keep it small and in a clean rectangle. No full-bleed cinematic images.

## Chart Style

- Background: white.
- Axes: `#CCCCCC`.
- Primary data: `#0066B1`.
- Secondary data: `#888888`.
- Positive: `#0066B1`; negative: `#D9534F`.
- Data labels: `#333333`.

## Do Not

- Use full-bleed background photography.
- Use all-caps titles.
- Use decorative shapes, gradients, or shadows.
- Use clip art or 3D graphics.
- Present raw data without a conclusion.

## Writing Rules

1. **Action title**: every slide title must state the takeaway.
2. **Pyramid principle**: conclusion first, then mutually exclusive arguments, then evidence.
3. **MECE**: supporting points must not overlap and must cover the full scope.
4. **Source everything**: every chart and number needs a source footer.
5. **So what?**: every data point must answer why it matters.

## Notes

- McKinsey decks are white, analytical, and text-dense. The premium feel comes from structure and rigor, not cinematic visuals.
*** Add File: /Users/james/note/premium-ppt/agents/openai.yaml
interface:
  display_name: "Premium PPT"
  short_description: "Build high-impact presentations in SpaceX, NVIDIA, or McKinsey style with cinematic imagery."
  default_prompt: "Use $premium-ppt to create a premium presentation. Ask me which style (spacex/nvidia/mckinsey), the decision goal, and the outline before building."
  parameters:
    - name: style
      type: enum
      values: [spacex, nvidia, mckinsey]
      description: "Visual style of the deck."
    - name: topic
      type: string
      description: "Topic or outline of the presentation."
