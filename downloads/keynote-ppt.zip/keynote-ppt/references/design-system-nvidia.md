# NVIDIA-Inspired Design System

# Keynote / Cinematic AI Infrastructure Presentation

## Visual Tokens

```yaml
canvas: "#000000"
headline: "#FFFFFF"
body: "#B8B8B8"
muted: "#808080"
accent: "#76B900"       # NVIDIA green
accent_secondary: "#D4AF37"  # gold for highlights / multiples
accent_tertiary: "#4A90E2"   # optional partner/tech blue
overlay: "#000000"      # used at 40–60% opacity over images
font_stack: "Arial, Aptos, Helvetica Neue, sans-serif"
title_case: "sentence"
ratio: "16:9"
margin_left: "0.6in"
margin_right: "0.6in"
margin_top: "0.5in"
margin_bottom: "0.5in"
```

## Typography Scale

| Element | Size | Weight | Color | Case |
|---------|------|--------|-------|------|
| Cover / big statement | 48–72 pt | Bold | `#FFFFFF` | Sentence |
| Section headline | 36–44 pt | Bold | `#FFFFFF` | Sentence |
| Subhead / quote | 24–32 pt | Regular | `#FFFFFF` or `#76B900` | Sentence |
| Metric / spec | 24–36 pt | Bold | `#FFFFFF` or `#76B900` | - |
| Body | 18–24 pt | Regular | `#B8B8B8` | Sentence |
| Label | 14–16 pt | Regular | `#808080` | UPPERCASE or Sentence |
| Caption / source | 12–14 pt | Regular | `#808080` | Sentence |

## Layout Patterns

### Cover
- Pure black background.
- NVIDIA-style logo centered (use placeholder, not official logo).
- Optional: full-bleed arena/audience photo with dark overlay, event title top-left.

### Trend / Evolution
- Black canvas.
- One large glowing green arrow/curve from left to right.
- Stages labeled in green or white along the curve.
- Small line-art icons at each stage.

### Product Spec
- Left 40%: full-height product photo (server rack, chip, hardware).
- Center 40%: title + specs, with green numbers for multiples (X).
- Right 20%: small chip/component images with labels.

### Architecture Diagram
- Title at top, centered or left-aligned.
- Dark rounded-rectangle cards with thin border (`#404040` or `#76B900` glow).
- Icons inside cards, connected by thin lines or arrows.
- Green/yellow accent for NVIDIA components, blue/white for partners.

### Chart / Performance
- Black background.
- Light axes (`#808080`).
- Data lines: `#76B900`, `#D4AF37`, `#FFFFFF`.
- Labels directly on the curve or near data points.

### Customer / Partner
- Partner logo on left (use placeholder).
- Large system diagram on right in dark card.
- Thin colored lines to show data flow.

### Quote / Press
- Full-bleed image or cinematic photo.
- Large quote in white, source below in gray.
- Optional green quote mark.

## Image Treatment

- Keywords: data center, GPU, server rack, chip, silicon wafer, factory, robot, autonomous vehicle, arena, stage lights, circuit board, neural network, glowing green lines.
- Full-bleed hardware photos with dramatic lighting.
- Product images should have dark background or be isolated on black.
- Architecture diagrams should have glowing edges, not flat shadows.

## Chart Style

- Background: black.
- Axes: `#808080`.
- Lines: `#76B900` for primary, `#D4AF37` for secondary, `#FFFFFF` for baseline.
- Data points: white or green dots.
- Avoid grid lines unless faint (`#333333`).

## Do Not

- Use McKinsey-style white backgrounds.
- Use decorative gradients or colored blocks.
- Overuse green: green is for accent only (logo, arrows, multiples, key labels).
- Put dense paragraphs on slides.

## Notes

- NVIDIA green is the signature. Use it sparingly so it has impact.
- The deck should feel like a stage keynote: big visuals, big numbers, minimal text.
