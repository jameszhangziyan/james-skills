# Story Card Template

Fill this card before building any deck. Paste it into the conversation or save it as a scratch file.

```markdown
## Story Card

### 1. Decision to Win
What must the audience decide after this deck? (fund / approve / partner / align / buy in)

Answer:

### 2. One-Sentence Takeaway
If the audience remembers only one sentence, what is it?

Answer:

### 3. Audience
Who is in the room? What do they care about? What is their skepticism?

Answer:

### 4. Tension
What is the costly status quo or the burning problem?

Answer:

### 5. Turning Point
What changed? What is the decisive insight, asset, or system?

Answer:

### 6. Hero Number
The single most important number + unit + time + source.

Answer:

### 7. Evidence
What 1–3 numbers, facts, or proofs make this credible?

Answer:

### 8. Consequence
What becomes possible if the audience says yes?

Answer:

### 9. Ask
What is the exact next step? (amount, owner, timeline, approval gate)

Answer:

### 10. Style
Which style fits this audience and moment? (spacex / nvidia / mckinsey)

Answer:

### 11. Slide Outline
Map the story beats to slide types.

| # | Slide Type | Title (conclusion) | Key Visual | Key Data |
|---|------------|-------------------|------------|----------|
| 1 | Cover | ... | ... | ... |
| 2 | ... | ... | ... | ... |
```
