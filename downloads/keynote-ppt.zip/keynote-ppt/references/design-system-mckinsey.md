# McKinsey-Inspired Design System

# Consulting / Strategy / Analytical Presentation

## Visual Tokens

```yaml
canvas: "#FFFFFF"
headline: "#333333"
body: "#555555"
muted: "#888888"
rule: "#CCCCCC"
accent: "#0066B1"        # McKinsey blue
accent_light: "#E6F0F8"  # light blue for fills
highlight: "#F3F3F3"      # light gray for alternating fills
font_stack: "Arial, Aptos, Calibri, Helvetica Neue, sans-serif"
title_case: "sentence"
ratio: "16:9"
margin_left: "0.6in"
margin_right: "0.6in"
margin_top: "0.5in"
margin_bottom: "0.5in"
```

## Typography Scale

| Element | Size | Weight | Color | Case |
|---------|------|--------|-------|------|
| Action title | 24–32 pt | Bold | `#333333` | Sentence |
| Section header | 20–24 pt | Bold | `#0066B1` | Sentence |
| Body | 14–18 pt | Regular | `#555555` | Sentence |
| Chart label | 12–14 pt | Regular | `#555555` | Sentence |
| Source / footer | 10–12 pt | Regular | `#888888` | Sentence |
| Page number | 10 pt | Regular | `#888888` | - |

## Layout Patterns

### Executive Summary
- Title: full-sentence conclusion.
- 3–4 supporting bullets below, each with a key number or fact.
- Optional chart or icon on right.

### Driver Tree / Issue Tree
- Top-down decomposition of a metric.
- Boxes connected by lines, arithmetic shown.
- Color: blue for primary metric, gray for sub-metrics.

### Waterfall Chart
- Bridge from baseline to target.
- Green/blue for positive drivers, red/orange for negative.
- Source footer below.

### 2x2 Matrix
- Two axes, four quadrants.
- Blue dots or labels for options/competitors.
- Clear quadrant labels.

### Roadmap / Plan
- Timeline columns: phase, owner, milestone, deliverable.
- Blue for active/initiatives, gray for future.

### Chart / Data
- White background, gray axes, blue bars/lines.
- Data labels directly on bars.
- Source footer mandatory.

### Ask / Next Steps
- White background.
- Title: recommended action.
- 3–4 concrete steps with owner and timeline.

## Image Treatment

- Images are rarely used. When needed, use simple icons, small photos, or conceptual visuals.
- Keywords: abstract business, teamwork, data analysis, city skyline, technology (use sparingly).
- If a photo is used, keep it small and in a clean rectangle. No full-bleed cinematic images.

## Chart Style

- Background: white.
- Axes: `#CCCCCC`.
- Primary data: `#0066B1`.
- Secondary data: `#888888`.
- Positive: `#0066B1`; negative: `#D9534F`.
- Data labels: `#333333`.

## Do Not

- Use full-bleed background photography.
- Use all-caps titles.
- Use decorative shapes, gradients, or shadows.
- Use clip art or 3D graphics.
- Present raw data without a conclusion.

## Writing Rules

1. **Action title**: every slide title must state the takeaway.
2. **Pyramid principle**: conclusion first, then mutually exclusive arguments, then evidence.
3. **MECE**: supporting points must not overlap and must cover the full scope.
4. **Source everything**: every chart and number needs a source footer.
5. **So what?**: every data point must answer why it matters.

## Notes

- McKinsey decks are white, analytical, and text-dense. The premium feel comes from structure and rigor, not cinematic visuals.
